<?php

$appName = "WebDroidX - Android WebView App";
$appVersion = "2.0.0";
$appCopyright = "Copyright © 2023 Solodroid Developer";
$menuDashboard = "Dashboard";
$menuDrawer = "Navigation";
$menuAds = "Ad Networks";
$menuNotification = "Notification";
$menuAdministrator = "Administrator";
$menuSettings = "Settings";
$menuApp = "Apps";
$menuLicense = "License";
$menuLogout = "Logout";

?>