<?php

$envatoPersonalToken = "VLfytVJ5JnU6Yx7zhoX6yPclHgAFMK9Z";
$envatoItemId = 46734998;
$postPerPage = 10;

?>