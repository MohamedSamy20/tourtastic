<?php

header("location: ../dashboard.php");
exit();

?>